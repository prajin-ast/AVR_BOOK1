/******************************************************************************
* Workfile    : EX0901.c
* Purpose     : Input Capture Mode
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>  // Deprecated items 

char toggle1=0;                  // Variable for Toggle bit
char toggle2=0;                  // Variable for Toggle bit

/************************************************************ Main Functions */
int main(void)
{       
    TCCR1B  = (1<<CS12)|(0<<CS11)|(1<<CS10); // clk_IO/1024 (From prescaler)

    // Activates Noise Canceler and Input Capture falling edgs
    TCCR1B |= (1<<ICNC1)|(1<<ICES1);         
    

    TIMSK = (1<<TICIE1);                    // Input Capture interrupt Enable
    TIMSK |= (1<<TOIE1);                    // T/C1 Overflow interrupt Enable
    sei();                                  // Set I-bit global interrupt enable
    
    
    DDRD  = (0<<DDB6);                      // PORT PD6(ICP1) Input 

    DDRA  = (1<<DDA1)|(1<<DDA0);            // PORT PA0 Output
    PORTA = (0<<PA1)|(0<<PA0);              // Clear port
    
    while (1);                              // Loop nothing

    return 0;
}

/****************************************** Timer/Counter1 Capture Interrupt */
ISR (TIMER1_CAPT_vect)
{  
    if((toggle1 = !toggle1))                // Toggle bit 
        sbi(PORTA, 0);                      // Set bit High
    else
        cbi(PORTA, 0);                      // Set bit Low

    return;
}

/***************************************** Timer/Counter1 Overflow Interrupt */
ISR (TIMER1_OVF_vect)
{  
    if((toggle2 = !toggle2))                // Toggle bit 
        sbi(PORTA, 1);                      // Set bit High
    else
        cbi(PORTA, 1);                      // Set bit Low

    return;
}
