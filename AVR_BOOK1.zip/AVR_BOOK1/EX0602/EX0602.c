/******************************************************************************
* Workfile    : EX0602.c
* Purpose     : Timer0, Overflow Interrupt
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>        // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

unsigned int count=0;		// Variable for count in interrupt function


/************************************************************ Main Functions */
int main(void)
{   
    // Set Timer/Counter0 Control register
    TCCR0 = (1<<CS02)|(0<<CS01)|(1<<CS00);  // clk_IO/1024 (From prescaler)
    TIMSK = (1<<TOIE0);                     // T/C0 Overflow interrupt Enable

    sei();                  // Set I-bit Global interrupt

    DDRA  = (1<<DDA0);      // PORT A0 Output
    PORTA = (0<<PA0);       // Clear port

    while (1);              // Loop nothing

    return 0;
}

/**************************************************** T/C0 Overflow Interrupt */
ISR (TIMER0_OVF_vect)
{
    static char toggle=0;

    if (count++ > 5) {                
        if (toggle) 
            sbi(PORTA,0);   // Set bit PA0
        else
            cbi(PORTA,0);   // Clear bit PA0        
        toggle = !toggle;   // Toggle
        count = 0;          // Clear counter  
    }
}
