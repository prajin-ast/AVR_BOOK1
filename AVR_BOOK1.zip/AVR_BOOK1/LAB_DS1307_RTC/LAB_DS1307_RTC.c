/******************************************************************************
* Workfile    : LAB_DS1307_RTC.c
* Purpose     : DS1307 (Real-Time Closk) with 
*             : Two-wire Serial Interface (TWI)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <util/twi.h>           // AVR TWI interface.

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#include "lib_UART.c"           // use library UART


/********************************************************************* Note */
/** 
* PC1 (SDA) pin 23
* PC0 (SCL) pin 22
*/

/*********************************************************** Address DS1307 */
#define TWI_SLA     0xD0        // Address DS1307 (11010000)


/************************************************************** Data Types */
typedef unsigned char byte;
typedef unsigned int  word;

/************************************************************** Structures */
typedef struct {
	byte sec;
	byte min;
	byte hour;
	byte day;
	byte date;
	byte month;
	byte year;
} RTC_TYPE;

RTC_TYPE RTC;


/***************************************************************** delay_ms */
void delay_ms(unsigned int i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/***************************************************************** TWI Start */
uint8_t TWI_Start()
{
    // Send START condition
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTA); 

    // wait for transmission
    while (!(TWCR & (1<<TWINT)))            
        ;

    switch (TW_STATUS) {
        // OK, start condition transmitted
        case TW_START:          
        case TW_REP_START:      
            return 1;
        // Arbitration lost in SLA+W or data
        case TW_MT_ARB_LOST:    
        default:
            return 0;		    
    }
}

/****************************************************************** TWI Stop */
void TWI_Stop()
{
    // Send STOP condition
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO); 
}

/****************************************************************** TWI Read */
uint8_t TWI_Read(uint8_t ack_bit)
{
    if (ack_bit) {
        // Start transmission, ACK Received
        TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);               
    } else {
        // Start transmission, NACK Received
        TWCR = (1<<TWINT)|(1<<TWEN);    
    }

    // Wait for transmission
    while (!(TWCR & (1<<TWINT)))        
        ;
    
    switch (TW_STATUS) {
        // Data received, ACK returned
        case TW_MR_DATA_ACK:    
        // Data received, NACK returned
        case TW_MR_DATA_NACK:   
            break;        
        
        // Arbitration lost in SLA+R or NACK
        case TW_MR_ARB_LOST:    
        default:
            return 0;
    }
    return(TWDR);       // Read TWDR
}

/***************************************************************** TWI Write */
uint8_t TWI_Write(uint8_t uc_data,uint8_t ack_bit)
{    
    TWDR = uc_data;     // Load SLA_W to TWDR

    if (ack_bit) {
        // Start transmission, ACK Received 
        TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
    } else {
        // Start transmission, NACK Received
        TWCR = (1<<TWINT)|(1<<TWEN);    
    }

    // Wait for transmission
    while (!(TWCR & (1<<TWINT)))        
        ;

    switch (TW_STATUS) {
        // SLA+W transmitted, ACK received
        case TW_MT_SLA_ACK:     
        // SLA+W transmitted, NACK received 
        case TW_MT_SLA_NACK:    
            return 1;

        // SLA+R transmitted, ACK received
        case TW_MR_SLA_ACK:     
        // SLA+R transmitted, NACK received
        case TW_MR_SLA_NACK:    
            return 2;

        // Data transmitted, ACK received
        case TW_MT_DATA_ACK:    
        // Data transmitted, NACK received
        case TW_MT_DATA_NACK:   
            return 3;    

        // Arbitration lost in SLA+W or data
        case TW_MT_ARB_LOST:    
        default:
            return 0;
    }
}

/*************************************************************** DS1307_Read */
uint8_t DS1307_Read(unsigned char ctl)
{
    unsigned char dat;

    TWI_Start();                            // Start condition 
    TWI_Write(TWI_SLA+TW_WRITE,1);          // TWI Write mode
    TWI_Write(ctl,0);                       // Control byte

    TWI_Start();                            // Start condition 
    TWI_Write(TWI_SLA+TW_READ,1);           // TWI Read mode
    dat = TWI_Read(0);                      // Read NACK Received
        
    TWI_Stop();                             // Stop condition

    return (dat);
}

/************************************************************** DS1307_Write */
void DS1307_Write(unsigned char ctl,unsigned char dat)
{
    TWI_Start();                            // Start condition 

    TWI_Write(TWI_SLA+TW_WRITE,1);          // TWI Write mode
    TWI_Write(ctl,1);                       // Control byte
    TWI_Write(dat,1);                       // Data byte

    TWI_Stop();                             // Stop condition
}

/*********************************************************** Real-Time Clock */
// Get Date/Time from RTC(DS1307)
void Read_RTC(void) 
{	
	RTC.sec   = DS1307_Read(0x00);
	RTC.min   = DS1307_Read(0x01); 
	RTC.hour  = DS1307_Read(0x02);
	RTC.date  = DS1307_Read(0x04);
	RTC.month = DS1307_Read(0x05); 
	RTC.year  = DS1307_Read(0x06);
}

// Set Date/Time to RTC(DS1307)
void Write_RTC(void) {

    int i;

    printf("\nSet Date/Time\n");
    printf("Date   : "); scanf("%x",&i); RTC.date = i;
    printf("Month  : "); scanf("%x",&i); RTC.month = i;
    printf("Year   : "); scanf("%x",&i); RTC.year = i;
    printf("Hour   : "); scanf("%x",&i); RTC.hour = i;
    printf("Minutes: "); scanf("%x",&i); RTC.min = i;
    printf("Seconds: "); scanf("%x",&i); RTC.sec = i;

    // Set Time
    DS1307_Write(0x00,RTC.sec);
	DS1307_Write(0x01,RTC.min);
	DS1307_Write(0x02,RTC.hour);
    // Set Date
    DS1307_Write(0x04,RTC.date);
	DS1307_Write(0x05,RTC.month);
	DS1307_Write(0x06,RTC.year);
}

// Display RTC(DS1307)
void Display_RTC(void) {

    printf("\fDS1307 Real Time Clock");

    // Print DATE
    printf("\nDate: ");
    if (RTC.date<10) printf("0%x/",RTC.date);
    else  printf("%x/",RTC.date);

    if (RTC.month<10) printf("0%x/",RTC.month);
    else printf("%x/",RTC.month);

    if (RTC.year<10) printf("0%x",RTC.year);
    else printf("%x",RTC.year);
    
    // Print TIME
    printf("\nTime: ");
    if (RTC.hour<10) printf("0%x:",RTC.hour);
    else printf("%x:",RTC.hour);

    if (RTC.min<10) printf("0%x:",RTC.min);
    else printf("%x:",RTC.min);

    if (RTC.sec<10) printf("0%x",RTC.sec);
    else printf("%x",RTC.sec);
}

/************************************************************ Main Functions */
int main(void)
{       
	char ch;

    // CPU Clock frequency: clk_IO/8 (From prescaler)
    TCCR1B  = (0<<CS12)|(1<<CS11)|(0<<CS10); 

    Init_Serial(96);      // Init Serial port

	printf("\fSet Real Time Clock ( y or n):");
	ch=getchar();

	if(ch == 'y' || ch == 'Y') { 	
		Write_RTC();
    }

	while (1) {
		Read_RTC();		
        Display_RTC();
        delay_ms(100);
	}

    return 0;
}
