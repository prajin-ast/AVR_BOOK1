/******************************************************************************
* Workfile    : LAB_Motor_DC.c
* Purpose     : DC Motor Control
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define DC_M_POUT		PORTA
#define DC_M_DDR		DDRA
#define DC_M_DDR_OUT 	(1<<DDA1)|(1<<DDA0)

#define MOTOR_LEFT  	0   // PIN PA0
#define MOTOR_RIGHT		1   // PIN PA1

#define MOTOR_ON(x)     sbi(DC_M_POUT, x);
#define MOTOR_OFF(x)    cbi(DC_M_POUT, x);
		
/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************ Motor control */
/** Motor_Forward */
void Motor_Forward(int speed, int time_drive)
{
    MOTOR_OFF(MOTOR_RIGHT);		// Motor right stop

    time_drive *= 10;
    for (;time_drive>0;time_drive--) {
		MOTOR_ON(MOTOR_LEFT);		    // Motor left start
        delay_ms(speed);
		MOTOR_OFF(MOTOR_LEFT);
        delay_ms(1);
    }
}

/** Motor_Backword */
void Motor_Backword(int speed, int time_drive)
{
    MOTOR_OFF(MOTOR_LEFT);       	// Motor left stop

    time_drive *= 10;
    for (;time_drive>0;time_drive--) {
		MOTOR_ON(MOTOR_RIGHT);	        // Motor right start	
        delay_ms(speed);
		MOTOR_OFF(MOTOR_RIGHT);
        delay_ms(1);
    }
}

/** Motor_Stop */
void Motor_Stop(int dly)
{
    MOTOR_OFF(MOTOR_RIGHT);	// Motor right stop
	MOTOR_OFF(MOTOR_LEFT);     // Motor left stop
    delay_ms(dly);
}

/************************************************************ Main Functions */
int main(void)
{        
	DC_M_DDR = DC_M_DDR_OUT;    // Set Port Output
 
    Motor_Stop(50);

    while (1) {        
		Motor_Forward(10, 100);
        Motor_Stop(100);
        Motor_Backword(10, 100);
        Motor_Stop(100);
    }

	return 0;
}
