/******************************************************************************
* Workfile    : EX1602.c
* Purpose     : Watchdog Timer
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#define _WDR() { __asm__ volatile ("WDR");}
		

/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/****************************************************************** WDT On */
void WDT_on(void) {

   // Write logical one to WDTOE and WDE
    WDTCR = (1<<WDTOE)|(1<<WDE);
    // Turn on WDT (time-out 2.1s)
    WDTCR |= 0x07;
}

/***************************************************************** WDT Off */
void WDT_off(void) {
    
    // Write logical one to WDTOE and WDE
    WDTCR = (1<<WDTOE)|(1<<WDE); 
   // Turn off WDT
    WDTCR = 0x00;
}


/************************************************************ Main Functions */
int main(void)
{
    int count=0;
        
    DDRA = (1<<DDA1)|(1<<DDA0); // PORT A Output all

    sbi(PORTA, 0);              // Set bit High
    delay_ms(2000);             // Delay 2s
    cbi(PORTA, 0);              // Set bit Low  

    WDT_on();                   // WDT Enable & Set Time-Out

    while (1) {                 // Loop forever

        cbi(PORTA, 1);          // Set bit Low  
        delay_ms(1000);         // Delay 1s
        _WDR();                 // Reset WDT
        sbi(PORTA, 1);          // Set bit High
        delay_ms(1000);         // Delay 1s
        _WDR();                 // Reset WDT

        if (count++ >=5) {
            while (1);          // Loop nothing
        }
	}

	return 0;
}
