/******************************************************************************
* Workfile    : EX0303.c
* Purpose     : PORTA Output
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>   // use sbi, cbi

unsigned int count=0;           // counter interrupt


/**************************************************************** loop_delay */
void loop_delay(unsigned long int count1)
{
    long i;
    while (count1-- > 0) {  // Decrease Counter
		for(i=0;i<1000;i++)
		;
    }
}

/************************************************************ Main Functions */
int main(void)
{   
    // PORT A Output all
    DDRA= (1<<DDA7)|(1<<DDA6)|(1<<DDA5)|(1<<DDA4)|      
          (1<<DDA3)|(1<<DDA2)|(1<<DDA1)|(1<<DDA0);          

    // Set Timer Prescaler (CLKio/1024)
    TCCR0 = (1<<CS02)|(0<<CS01)|(1<<CS00);             

    // Set Interrupt Timer0            
    TIMSK = (1<<TOIE0);                 // T/C0 Overflow interrupt Enable 
    TIFR  = (1<<TOV0);                  // Set T/C0 Overflow flag
    SREG  = 0x80;                       // Set I-bit Global interrupt    

	PORTA= 0x00;                        // Clear port

    while (1) {                         // loop forever   
        sbi(PORTA,0);                   // Set bit PA0
        loop_delay(100);                // delay
        cbi(PORTA,0);                   // Clear bit PA0
        loop_delay(100);                // delay
    }

    return 0;
}

/*************************************************** Timer/Counter0 Overflow */
// Timer0 Interrupt
ISR (TIMER0_OVF_vect)
{    
    count++;
    if (count == 6) {        
        sbi(PORTA,7);                   // Set bit PA7
    }
    if (count == 12) {
        cbi(PORTA,7);                   // Clear bit PA7      
        count = 0;                      // Clear counter    
    }    
}
