/******************************************************************************
* Workfile    : EX0406.c
* Purpose     : PA0/PA1 Input Output & PA2
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function


/************************************************************ Main Functions */
int main(void)
{  
    // PORT PA2 Output ,PA1&PA0 Input
    DDRA = (1<<DDA2)|(0<<DDA1)|(0<<DDA0);   
    cbi(PORTA,2);                   // Clear port PA2
    
    while (1) {
//        if ((PINA&0x01)==0) {       // Check input PA0
        if ((PINA&(1<<PINA0))==0) { // Check input PA0
            sbi(PORTA,2);  	        // Output High
        } 
//        if ((PINA&0x02)==0) {       // Check input PA1
        if ((PINA&(1<<PINA1))==0) { // Check input PA1
            cbi(PORTA,2);           // Output low
        }   
    }

    return 0;
}
