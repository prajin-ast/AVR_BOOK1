/******************************************************************************
* Workfile    : LAB_Motor_Servo.c
* Purpose     : Servo Motor Control
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files : 
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#define SERVO_M_POUT    PORTA
#define SERVO_M_DDR     DDRA
#define SERVO_M_DDR_OUT (1<<DDA0)
#define SERVO_PIN       PA0

#define	PULSE_LEFT		2       // 2.0	ms
#define PULSE_RIGHT		1       // 1.0 ms
#define	PULSE_STOP		1500    // 1.5 ms (1500us)
#define PULSE_LOW		10      // 10.0 ms


#define SERVO_HIGH(x)   sbi(SERVO_M_POUT, x)
#define SERVO_LOW(x)    cbi(SERVO_M_POUT, x)
		
#define delay_ms(x)     _delay_ms(x)


/****************************************************************** delay_us */
void delay_us(unsigned int i)
{
    for (;i > 0; i--)
        _delay_us(1);
}

/************************************************************** Servo Control */
/** Driver motor forware, backword, stop */
/** Clockwise */
void servo_left(unsigned int pos)
{
    for (;pos>0;pos--) {
        SERVO_HIGH(SERVO_PIN);
        delay_ms(PULSE_RIGHT);
        SERVO_LOW(SERVO_PIN);
        delay_ms(PULSE_LOW);
    }
}
/** Counterclockwise */
void servo_right(unsigned int pos)
{
    for (;pos>0;pos--) {
        SERVO_HIGH(SERVO_PIN);
        delay_ms(PULSE_LEFT);
        SERVO_LOW(SERVO_PIN);
        delay_ms(PULSE_LOW);
    }
}
/** Center */
void servo_stop(unsigned int wait)
{
    for (;wait>0;wait--) {
        SERVO_HIGH(SERVO_PIN);
        delay_us(PULSE_STOP);
        SERVO_LOW(SERVO_PIN);
        delay_ms(PULSE_LOW);
    }
}

/************************************************************* Main Function */
int main(void)
{
    SERVO_M_DDR = SERVO_M_DDR_OUT;		// set port pins to output

    while (1) {
        servo_left(500);               // move left
        servo_stop(100);               // stop
        servo_right(500);              // move right
        servo_stop(100);               // stop
    }

    return 0;
}
