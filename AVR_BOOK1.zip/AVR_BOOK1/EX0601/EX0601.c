/******************************************************************************
* Workfile    : EX0601.c
* Purpose     : Timer0, Check Timer/Counter register
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function


/************************************************************ Main Functions */
int main(void)
{   
    unsigned int count=0;
    char toggle=0;

    // Set Timer/Counter0 Control register
    TCCR0 = (1<<CS02)|(0<<CS01)|(1<<CS00);  // clk_IO/1024 (From prescaler)

    DDRA  = (1<<DDA0);                      // PORT A0 Output
    PORTA = (0<<PA0);                       // Clear PORT PA0

    while (1) {                             // Loop Forever
        if ((TIFR&(1<<TOV0)) == 1) {        // Wait for TOV0 set
            TIFR = (1<<TOV0);               // Clear TOV0 bit
            if (count++ > 5) {              // Wait for count > 5               
                if (toggle) 
                    sbi(PORTA,0);           // Set bit PA0
                else
                    cbi(PORTA,0);           // Clear bit PA0        
                toggle = !toggle;           // Toggle
                count = 0;                  // Clear counter  
            }
        }
    }

    return 0;
}

    
