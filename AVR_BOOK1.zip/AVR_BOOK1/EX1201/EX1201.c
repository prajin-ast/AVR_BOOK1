/******************************************************************************
* Workfile    : EX1201.c
* Purpose     : Two-wire Serial Interface (TWI)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <util/twi.h>           // AVR TWI interface.

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

/********************************************************* Address PCF8574A */
#define TWI_SLA     0x70        // Address 01110000


/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/***************************************************************** TWI Start */
uint8_t TWI_Start()
{
    // Send START condition
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTA); 

    // wait for transmission
    while (!(TWCR & (1<<TWINT)))            
        ;

    switch (TW_STATUS) {
        // OK, start condition transmitted
        case TW_START:          
        case TW_REP_START:      
            return 1;
        // Arbitration lost in SLA+W or data
        case TW_MT_ARB_LOST:    
        default:
            return 0;		    
    }
}

/****************************************************************** TWI Stop */
void TWI_Stop()
{
    // Send STOP condition
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO); 
}

/****************************************************************** TWI Read */
uint8_t TWI_Read(uint8_t ack_bit)
{
    if (ack_bit) {
        // Start transmission, ACK Received
        TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);               
    } else {
        // Start transmission, NACK Received
        TWCR = (1<<TWINT)|(1<<TWEN);    
    }

    // Wait for transmission
    while (!(TWCR & (1<<TWINT)))        
        ;
    
    switch (TW_STATUS) {
        // Data received, ACK returned
        case TW_MR_DATA_ACK:    
        // Data received, NACK returned
        case TW_MR_DATA_NACK:   
            break;        
        
        // Arbitration lost in SLA+R or NACK
        case TW_MR_ARB_LOST:    
        default:
            return 0;
    }
    return(TWDR);       // Read TWDR
}

/***************************************************************** TWI Write */
uint8_t TWI_Write(uint8_t uc_data,uint8_t ack_bit)
{    
    TWDR = uc_data;     // Load SLA_W to TWDR

    if (ack_bit) {
        // Start transmission, ACK Received 
        TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
    } else {
        // Start transmission, NACK Received
        TWCR = (1<<TWINT)|(1<<TWEN);    
    }

    // Wait for transmission
    while (!(TWCR & (1<<TWINT)))        
        ;

    switch (TW_STATUS) {
        // SLA+W transmitted, ACK received
        case TW_MT_SLA_ACK:     
        // SLA+W transmitted, NACK received 
        case TW_MT_SLA_NACK:    
            return 1;

        // SLA+R transmitted, ACK received
        case TW_MR_SLA_ACK:     
        // SLA+R transmitted, NACK received
        case TW_MR_SLA_NACK:    
            return 2;

        // Data transmitted, ACK received
        case TW_MT_DATA_ACK:    
        // Data transmitted, NACK received
        case TW_MT_DATA_NACK:   
            return 3;    

        // Arbitration lost in SLA+W or data
        case TW_MT_ARB_LOST:    
        default:
            return 0;
    }
}

/************************************************************* PCF8574A_Read */
uint8_t PCF8574A_Read(void)
{
    uint8_t twi_dat;

    TWI_Start();                            // Start condition 

    TWI_Write(TWI_SLA+TW_READ,1);           // TWI Read mode

    twi_dat = TWI_Read(0);                  // Read NACK Received
    twi_dat = (twi_dat<<4)|(twi_dat>>4);    // Swap Nibble bit
    twi_dat |= 0xF0;                        // Or bit use LSB
        
    TWI_Stop();                             // Stop condition

    return (twi_dat);
}

/************************************************************ PCF8574A_Write */
void PCF8574A_Write(uint8_t twi_dat)
{
    TWI_Start();                            // Start condition 

    TWI_Write(TWI_SLA+TW_WRITE,1);          // TWI Write mode
    TWI_Write(twi_dat,1);

    TWI_Stop();                             // Stop condition
}

/************************************************************ Main Functions */
int main(void)
{       
    uint8_t twi_dat=0x00;

    // clk_IO/8 (From prescaler)
    TCCR1B  = (0<<CS12)|(1<<CS11)|(0<<CS10); 
    
    while (1) {
        twi_dat = PCF8574A_Read();
        PCF8574A_Write(twi_dat);
        delay_ms(1000);                    // Delay 1s
    }

    return 0;
}
