/******************************************************************************
* Workfile    : lib_UART.c
* Purpose     : UART Library
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files : lib_UART.h
* Ref         :
******************************************************************************/

#include "lib_UART.h"


/********************************************************************** Note */
// use:
// 
// Init_Serial(unsigned int baudrate) Must be called before any other function.
// 
// Stream I/O
// fprintf(&uart_str,"\f\nTime %d:%d:%d\n",hr,min,sec);
//
// char buf[20];
// printf("Hello, world!\n",buf);
//
// #include "D:\AST_Course\AVR Course\EX Course AVR\lib_UART.c"
// Init_Serial(96);
// while(1) {
//     fprintf(&uart_str,"\f\n TCNT0 : %d",TCNT0);
//     delay_1s();
// }
//
//
//

/****************************************************************** delay_1s */
static void delay_1s(void)
{
    uint8_t i;

    for (i = 0; i < 100; i++)
        _delay_ms(10);
}

/************************************************************* USART putchar */
static int uart_putchar(char c, FILE *stream)
{
    if (c == '\a') {
        fputs("*ring*\n", stderr);
        return 0;
    }

    if (c == '\n')
        uart_putchar('\r', stream);
    
    loop_until_bit_is_set(UCSRA, UDRE);
    UDR = c;

    return 0;
}

/*********************************************************** Initialize UART */
static void USART_Init(unsigned int baud)
{
	// Set baud rate
	UBRRH = (unsigned char) (baud>>8);
	UBRRL = (unsigned char) baud;
    
	// Enable receiver and tramsmitter
	UCSRB = (1<<RXEN) | (1<<TXEN);

	// Set frame format: 8data, NoneParity, 1stop bit
	UCSRC = (1<<URSEL)|(3<<UCSZ0);
}

/*************************************************************** Init_Serial */
void Init_Serial(unsigned int baudrate)
{    
    unsigned int baud;

    switch (baudrate) {
        case 96:
            baud = 51;      // baudrate to 9,600 bps using a 8MHz crystal
        default:
            baud = 51;
    }
    
    USART_Init( baud );  
    
    stdout = &uart_str;     // Set address uart_str to stdout
}
