/******************************************************************************
* Workfile    : EX1402.c
* Purpose     : Analog to Digital Converter (ADC)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#include "lib_UART.c"  			// Use Module USART          

#define Vadc	1023			// 1023 (10-bit Resolution)

/***************************************************************** delay_ms */
void delay_ms(uint8_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{       
	unsigned int adc;
    unsigned char ch_adc=0x00;

    Init_Serial(96);				// Init Serial port  

	// ADC Enable & Auto Trigger Disable
	ADCSRA = (1<<ADEN)|(0<<ADATE);
	ADCSRA |= (0<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);	// XTAL/8
    
    while (1) {

        printf("\fAnalog to Digital Converter (ADC)");

        for(ch_adc=0x00; ch_adc<0x08; ch_adc++) {
            
            // AVCC with external capacitor at AREF pin
            // Select Analog Channel
            ADMUX = (0<<REFS1)|(1<<REFS0)|ch_adc; 

            ADCSRA |= (1<<ADSC);			// ADC Start Conversion
            while (!(ADCSRA &(1<<ADIF)))    // Wait Coversion completes
                ;
    		adc = ADCW;                     // Read ADC
    
	    	printf("\nADC%d: %d Voltage: %d.%d V", \ 
//				    ch_adc,adc,(adc*5)/Vadc,(adc*5)%Vadc);                    
					ch_adc,adc,(adc*5)/Vadc,(((adc*5)%Vadc)*10)/Vadc);	
        }
        delay_ms(1000);                 // Delay 1s
    }

    return 0;
}
