/******************************************************************************
* Workfile    : LAB_LCD_01.c
* Purpose     : LCD Display 01
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files : lcdconf.h
* Ref         : Procyon AVRlib (C-Language Function Library 
*			  : for Atmel AVR Processors)
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>		// include I/O definitions (port names, pin names, etc)
#include <avr/signal.h>	// include "signal" names (interrupt names)
#include <avr/interrupt.h>	// include interrupt support

/*********************************************************** Procyon AVRlib */
#include "timer.c"		// include Timer function library
#include "lcd.c"		// include LCD function library


/************************************************************ Main Functions */
int main(void)
{	
	unsigned int maxprogress=500;
	unsigned int progress=0;
	unsigned char length=16;
	unsigned char set_updown=1;

	// initialize all timers
	timerInit();

	// initializes the LCD display
	lcdInit();

	lcdGotoXY(0,0); 
	lcdPrintData("+-- LCD Demo --+",16);	

    while (1) {                 // Loop forever
		lcdGotoXY(0,1); 
		lcdProgressBar(progress, maxprogress, length);
		timerPause(100);		// Delay 100ms

		if (progress >= maxprogress) set_updown = 0;	
		if (progress <= 0) set_updown = 1;

		if (set_updown)
			progress +=10;
		else
			progress -=10;
	}
	return 0;
}
