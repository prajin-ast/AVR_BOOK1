/******************************************************************************
* Workfile    : EX0501.c
* Purpose     : External Interrupt (INT0)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

unsigned char i=0;

/****************************************************************** delay_ms */
void delay_ms(unsigned int i)
{        
    for (; i>0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{    
    // The rising edge of INT0 generates an interrupt request
    MCUCR = (1<<ISC01)|(1<<ISC00);      

    GICR  = (1<<INT0);      // Enable INT0 interrupt    
    SREG  = 0x80;           // Set I-bit Global interrupt    

    DDRA  = (1<<DDA0);		// PORT A0 Output
    PORTA = (0<<PA0);		// Clear port

    while (1) {             // Loop nothing
		;
    }

    return 0;
}

/*********************************************** External Interrupt Request 0 */
// Interrupt INT0 (Port PD2)
ISR (INT0_vect)
{
    if (i) 
        sbi(PORTA,0);       // Set bit 
    else
        cbi(PORTA,0);       // Clear bit

    i = !i;                 // Toggle bit
    delay_ms(200);         	// Delay debound
}

