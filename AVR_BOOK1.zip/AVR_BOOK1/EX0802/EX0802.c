/******************************************************************************
* Workfile    : EX0802.c
* Purpose     : Fast PWM Mode
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine

#define F_CPU 8000000UL     // CPU clock frequency (in Hertz)    
#include <util/delay.h>     // util_delay

unsigned int count=0;       // counter interrupt


static void delay_1s(void)
{
    uint8_t i;

    for (i = 0; i < 100; i++)
        _delay_ms(10);
}

/************************************************************ Main Functions */
int main(void)
{       
    unsigned char up_ocr0=0;

    TCCR0 =  (1<<CS02)|(0<<CS01)|(1<<CS00); // clk_IO/1024 (From prescaler)
    TCCR0 |= (1<<WGM01)|(1<<WGM00);         // Fast PWM
    TCCR0 |= (1<<COM01)|(0<<COM00);         // Clear OC0 on compare match,Set OC0 at TOP
    
    TIMSK = (1<<TOIE0);                     // T/C0 Overflow interrupt Enable
    sei();                                  // Set I-bit global interrupt enable

    DDRB  = (1<<DDB3);                      // PORT PB3 Output
    DDRA  = (1<<DDA0);                      // PORT PA0 Output
    PORTA = (0<<PA0);                       // Clear port
    
    while (1) {                             // Loop forever        
        up_ocr0 += 5;
        OCR0 = up_ocr0;                     // Set OCR0 Compare Match   
        delay_1s();
    }

    return 0;
}

/*************************************************** T/C0 Overflow Interrupt */
ISR (TIMER0_OVF_vect)
{  
    PORTA = !(PORTA);                       // Toggle PA0
    return;
}
