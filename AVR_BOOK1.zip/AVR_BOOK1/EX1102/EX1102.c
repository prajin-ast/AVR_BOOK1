/******************************************************************************
* Workfile    : EX1102.c
* Purpose     : Interrupt Serial Peripheral Interface (SPI)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL     // CPU clock frequency (in Hertz)    
#include <util/delay.h>     // util_delay


/******************************************************** Define PIN MC14489 */
#define PORT_EN     PORTB       // SPI PORT EN
#define DDR_SPI     DDRB        // SPI PORT PIN
#define DD_ENB      DDB0        // ENB (EN)  pin(PB0) 
#define DD_SS       DDB4        // SS  (SS)  pin(PB4)
#define DD_MOSI     DDB5        // MOSI(DI)  pin(PB5)
#define DD_SCK      DDB7        // SCK (CLK) pin(PB7)

unsigned int toggle_PA0 = 1;    // for Toggle in SPI Interrupt

/****************************************************************** delay_ms */
static void delay_ms(unsigned int i)
{
    for (; i>0; i--)
        _delay_ms(1);
}

/*********************************************************** SPI Master Init */
void SPI_MasterInit(void)
{
    // Set MOSI, SCK and ENB output, all other input
    DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK)|(1<<DD_ENB)|(1<<DD_SS);

    // Enable SPI, Master, set clock rate fck/64 
    SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR1)|(0<<SPR0);
    // Enable SPI Interrupt
    SPCR |= (1<<SPIE);
    // Set I-bit global interrupt enable
    sei();                      

    DDRA = (1<<DDA0);           // Set PA0 output port
}

/******************************************************* SPI Master Transmit */
void SPI_MasterTransmit(char cData)
{        
    // Start transmission
    SPDR = cData;                   
    // Wait for transmission complete
    while (!(SPSR & (1<<SPIF)))   
        ;
}

/******************************************************************** SPI TX */
void SPI_TX(unsigned long content)
{
    cbi(PORT_EN, 0);                            // Clear bit
    SPI_MasterTransmit((char)(content>>16));    // Write bit 32-17
    SPI_MasterTransmit((char)(content>>8));     // Write bit 16-8
    SPI_MasterTransmit((char)(content));        // Write bit 7-0
    sbi(PORT_EN, 0);                            // Set bit
}

/****************************************************************** CountNum */
unsigned long CountNum() 
{
    static unsigned long num = 0x800000;

    if (num++ >= 0x899999) {    // num = 99999
        num = 0x800000;         // num = 0        
    }

    if((num&0x80000A)==0x80000A) num += 0x06;
    if((num&0x8000A0)==0x8000A0) num += 0x60;
    if((num&0x800A00)==0x800A00) num += 0x600;
    if((num&0x80A000)==0x80A000) num += 0x6000;
    if((num&0x8A0000)==0x8A0000) num += 0x60000;

    return(num);
}

/************************************************************ Main Functions */
int main(void)
{           
    SPI_MasterInit();           // Initialize SPI

    cbi(PORT_EN, 0);            // Clear bit
    SPI_MasterTransmit(0x01);   // Initialize MC14489
    sbi(PORT_EN, 0);            // Set bit

    SPI_TX(0x0ABCDE);           // Write ABCEDE
    delay_ms(1000);             // Delay 1s
    
    while (1) {                 // Loop forever        
        SPI_TX(CountNum());     // Send counting-up
        delay_ms(500);          // Delay 0.5s        
    }

    return 0;
}

/************************************************** Serial Transfer Complete */
ISR (SPI_STC_vect)
{  
    if (toggle_PA0)    
        sbi(PORTA, 0);              // Set PA0
    else
        cbi(PORTA, 0);              // Clear PA0

    toggle_PA0 = !toggle_PA0;
    return;
}
