/******************************************************************************
* Workfile    : LAB_Macro_Function.c
* Purpose     : Macro
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


#define toggle(p,b)		( !(p&(1<<b)) ? (sbi(p,b)):(cbi(p,b)) )

/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{   
	DDRA = (1<<DDA7)|(1<<DDA5);	// Set PA5&PA7 Output
	PORTA = (1<<PA7)|(1<<PA5);	// Output PA7&PA5

    while (1) {      			// Loop forever
		toggle(PORTA,PA5);		// Toggle PA5
		toggle(PORTA,PA7);		// Toggle PA7
		delay_ms(1000);			// Delay 1s		
	}

	return 0;
}
