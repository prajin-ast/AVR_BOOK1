/******************************************************************************
* Workfile    : lib_UART.h
* Purpose     : UART Library
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */

#include <stdio.h>          // Standard Input/Output
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine

#define F_CPU 8000000UL     // CPU clock frequency (in Hertz)    
#include <util/delay.h>     // util_delay

#define RX_BUFSIZE 80       // Buffer RX


/******************************************************* Prototype functions */
static int uart_putchar(char c, FILE *stream);
static int uart_getchar(FILE *stream);
static FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, uart_getchar, _FDEV_SETUP_RW);
void Init_Serial(unsigned int baudrate);
