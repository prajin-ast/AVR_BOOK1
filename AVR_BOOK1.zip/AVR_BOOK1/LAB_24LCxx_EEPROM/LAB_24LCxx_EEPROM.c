/******************************************************************************
* Workfile    : LAB_24LCxx_EEPROM.c
* Purpose     : Serial EEPROM (24LCxx) with 
*             : Two-wire Serial Interface (TWI)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <util/twi.h>           // AVR TWI interface.

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#include "lib_UART.c"           // use library UART

/********************************************************************* Note */
/** 
* PC0 (SCL) pin 22
* PC1 (SDA) pin 23
*/

/************************************************************ Address 24LCxx */
#define TWI_SLA		0xA0        	// Address 24LCxx Serial EEPROM
#define wait_write	_delay_ms(5)	// 5 ms max write-cycle time


/***************************************************************** TWI Start */
uint8_t TWI_Start()
{
    // Send START condition
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTA); 

    // wait for transmission
    while (!(TWCR & (1<<TWINT)))            
        ;

    switch (TW_STATUS) {
        // OK, start condition transmitted
        case TW_START:          
        case TW_REP_START:      
            return 1;
        // Arbitration lost in SLA+W or data
        case TW_MT_ARB_LOST:    
        default:
            return 0;		    
    }
}

/****************************************************************** TWI Stop */
void TWI_Stop()
{
    // Send STOP condition
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO); 
}

/****************************************************************** TWI Read */
uint8_t TWI_Read(uint8_t ack_bit)
{
    if (ack_bit) {
        // Start transmission, ACK Received
        TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);               
    } else {
        // Start transmission, NACK Received
        TWCR = (1<<TWINT)|(1<<TWEN);    
    }

    // Wait for transmission
    while (!(TWCR & (1<<TWINT)))        
        ;
    
    switch (TW_STATUS) {
        // Data received, ACK returned
        case TW_MR_DATA_ACK:    
        // Data received, NACK returned
        case TW_MR_DATA_NACK:   
            break;        
        
        // Arbitration lost in SLA+R or NACK
        case TW_MR_ARB_LOST:    
        default:
            return 0;
    }
    return(TWDR);       // Read TWDR
}

/***************************************************************** TWI Write */
uint8_t TWI_Write(uint8_t uc_data,uint8_t ack_bit)
{    
    TWDR = uc_data;     // Load SLA_W to TWDR

    if (ack_bit) {
        // Start transmission, ACK Received 
        TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
    } else {
        // Start transmission, NACK Received
        TWCR = (1<<TWINT)|(1<<TWEN);    
    }

    // Wait for transmission
    while (!(TWCR & (1<<TWINT)))        
        ;

    switch (TW_STATUS) {
        // SLA+W transmitted, ACK received
        case TW_MT_SLA_ACK:     
        // SLA+W transmitted, NACK received 
        case TW_MT_SLA_NACK:    
            return 1;

        // SLA+R transmitted, ACK received
        case TW_MR_SLA_ACK:     
        // SLA+R transmitted, NACK received
        case TW_MR_SLA_NACK:    
            return 2;

        // Data transmitted, ACK received
        case TW_MT_DATA_ACK:    
        // Data transmitted, NACK received
        case TW_MT_DATA_NACK:   
            return 3;    

        // Arbitration lost in SLA+W or data
        case TW_MT_ARB_LOST:    
        default:
            return 0;
    }
}

/*************************************************************** EEPROM_Read */
uint8_t EEPROM_Read(unsigned int adr)
{
    unsigned char dat;

    TWI_Start();                            // Start condition 
    TWI_Write(TWI_SLA+TW_WRITE,1);          // TWI Write mode
    TWI_Write(adr>>8,1);                   	// Address High Byte
	TWI_Write(adr,1);                   	// Address Low Byte

    TWI_Start();                            // Start condition 
    TWI_Write(TWI_SLA+TW_READ,1);           // TWI Read mode
    dat = TWI_Read(0);                      // Read ACK Received
        
    TWI_Stop();                             // Stop condition

    return (dat);
}

/************************************************************** EEPROM_Write */
void EEPROM_Write(unsigned int adr,unsigned char dat)
{
    TWI_Start();                            // Start condition 

    TWI_Write(TWI_SLA+TW_WRITE,1);          // TWI Write mode
    TWI_Write(adr>>8,1);                   	// Address High Byte
	TWI_Write(adr,1);                   	// Address Low Byte

    TWI_Write(dat,1);                       // Data byte

    TWI_Stop();                             // Stop condition
}

/************************************************************ Main Functions */
int main(void)
{       
	unsigned int ee_adr;
	unsigned char dat=1;
	
    // CPU Clock frequency: clk_IO/8 (From prescaler)
    TCCR1B  = (0<<CS12)|(1<<CS11)|(0<<CS10); 

    Init_Serial(96);      // Init Serial port

	printf("\f24LCxx Serial EEPROM Write/Read");

	for (ee_adr=0x0000; ee_adr<=0x000F; ee_adr++) {
		// Write data
    	EEPROM_Write(ee_adr,dat++);		
		// Wait for write-cycle time
		wait_write;						
	}
	printf("\nWrite EEPROM Complete...");
    
	for (ee_adr=0x0000; ee_adr<=0x000F; ee_adr++) {
    	printf("\nRead EEPROM @%X data: %d",
				 ee_adr,EEPROM_Read(ee_adr));
	}

	while (1);			// Loop Nothing

    return 0;
}
