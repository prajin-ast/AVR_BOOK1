/******************************************************************************
* Workfile    : LAB_LCD_02.c
* Purpose     : LCD Display 02
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files : lcdconf.h
* Ref         : Procyon AVRlib (C-Language Function Library 
*			  : for Atmel AVR Processors)
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>		// include I/O definitions (port names, pin names, etc)
#include <avr/signal.h>	// include "signal" names (interrupt names)
#include <avr/interrupt.h>	// include interrupt support
#include <stdio.h>		// include Standard I/O Library

/*********************************************************** Procyon AVRlib */
#include "timer.c"		// include Timer function library
#include "lcd.c"		// include LCD function library
#include "a2d.c"		// include A/D converter function library


/************************************************************ LCD Put String */
void lcdPutString(char *text)
{
	while ( *text ) {			// while not end of text
  	
  		lcdDataWrite(*text++); 	// Write character and increment position
  	} 

	return;
}

/************************************************************ Main Functions */
int main(void)
{
	unsigned char ch_adc;
	unsigned char adc[5];

	// initializes the LCD display
	lcdInit();

	// Turns ADC on and prepares it for use.
	a2dInit();

    while (1) {                 // Loop forever

		for (ch_adc=0; ch_adc<4; ch_adc++) {

			sprintf(adc,"%d",a2dConvert10bit(ch_adc));

			if (ch_adc==0) { 
				lcdGotoXY(0,0); lcdPrintData("CH0:    ",8);
				lcdGotoXY(4,0); lcdPutString(adc);
			}
			if (ch_adc==1) { 
				lcdGotoXY(8,0); lcdPrintData("CH1:    ",8);
				lcdGotoXY(12,0); lcdPutString(adc);
			}
			if (ch_adc==2) { 
				lcdGotoXY(0,1); lcdPrintData("CH2:    ",8);
				lcdGotoXY(4,1); lcdPutString(adc);
			}
			if (ch_adc==3) { 
				lcdGotoXY(8,1); lcdPrintData("CH3:    ",8);
				lcdGotoXY(12,1); lcdPutString(adc);
			}			
		}
	}
	return 0;
}
