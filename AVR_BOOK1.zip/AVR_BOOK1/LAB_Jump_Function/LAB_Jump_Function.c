/******************************************************************************
* Workfile    : LAB_Jump_Function.c
* Purpose     : Jump Function non-local goto
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include <setjmp.h>         // Library Non-local goto

jmp_buf env;


/****************************************************** Function Prototypes */
void toggle_led(void);


/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{
    sbi(DDRA,0);        // Set PA0&PA1 output
    sbi(DDRA,1);

    if (setjmp (env)) { // Longjmp call goto here
        sbi(PORTA,1);
        delay_ms(1000);
        cbi(PORTA,1);
        delay_ms(1000);
    }

    while (1) {         // Loop forever
        toggle_led();
    }

    return 0;
}

/**************************************************************** Toggle LED */
void toggle_led(void) 
{
    static int count_jmp=0;
    
    sbi(PORTA,0);           // Toggle
    delay_ms(1000);
    cbi(PORTA,0);
    delay_ms(1000);

    if (count_jmp++ > 10)   // Count
    {
        count_jmp = 0;      // Clear count
        longjmp (env, 1);   // Goto function setjmp in Main program
    }
}
