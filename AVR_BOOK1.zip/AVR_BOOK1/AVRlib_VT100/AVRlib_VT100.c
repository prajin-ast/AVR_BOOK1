//----- Include Files ---------------------------------------------------------
#include <avr/io.h>		// include I/O definitions (port names, pin names, etc)
#include <avr/signal.h>	// include "signal" names (interrupt names)
#include <avr/interrupt.h>	// include interrupt support

#include "global.h"		// include our global settings
#include "uart.h"		// include uart function library
#include "rprintf.h"	// include printf function library
#include "vt100.h"		// include VT100 terminal support


//----- Begin Code ------------------------------------------------------------
int main(void)
{
	// initialize our libraries
	// initialize the UART (serial port)
	uartInit();
	// set the baud rate of the UART for our debug/reporting output
	uartSetBaudRate(9600);

	// initialize rprintf system
	// - use uartSendByte as the output for all rprintf statements
	//   this will cause all rprintf library functions to direct their
	//   output to the uart
	// - rprintf can be made to output to any device which takes characters.
	//   You must write a function which takes an unsigned char as an argument
	//   and then pass this to rprintfInit like this: rprintfInit(YOUR_FUNCTION);
	rprintfInit(uartSendByte);

	// initialize vt100 library
	vt100Init();
	
	// clear the terminal screen
	vt100ClearScreen();
	
//    vt100SetCursorMode(0);

    vt100SetAttr(VT100_BOLD);
//    vt100SetAttr(30);
//    vt100SetAttr(43);

    vt100SetCursorPos(10,10);

	rprintf("TEST VT100 ANSI Terminal");

    while (1)
        ;

	return 0;
}

