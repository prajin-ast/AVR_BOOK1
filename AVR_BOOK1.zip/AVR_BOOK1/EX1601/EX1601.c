/******************************************************************************
* Workfile    : EX1601.c
* Purpose     : Watchdog Timer
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 
#include <avr/wdt.h>        // macros for AVR watchdog timer

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops


/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{
    int count=0;

    wdt_disable();              // WDT Disable
        
    DDRA = (1<<DDA1)|(1<<DDA0); // PORT A Output all

    sbi(PORTA, 0);              // Set bit High
    delay_ms(2000);             // Delay 2s
    cbi(PORTA, 0);              // Set bit Low  

    wdt_enable(WDTO_2S);        // WDT Enable & Set Time-Out

    while (1) {                 // Loop forever

        cbi(PORTA, 1);          // Set bit Low  
        delay_ms(1000);         // Delay 1s
        wdt_reset();            // Reset WDT
        sbi(PORTA, 1);          // Set bit High
        delay_ms(1000);         // Delay 1s
        wdt_reset();            // Reset WDT

        if (count++ >=5) {
            while (1);          // Loop nothing
        }
	}

	return 0;
}
