/******************************************************************************
* Workfile    : LAB_Sleep_Mode.c
* Purpose     : Power Management (Sleep Modes)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>	        // AVR device-specific IO definitions
#include <avr/sleep.h>	    // Power Management and Sleep Modes
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


#define toggle(p,b)		( !(p&(1<<b)) ? (sbi(p,b)):(cbi(p,b)) )


/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/******************************************************************* Timer2 */
void Init_Timer2(void)
{
    // Set Timer/Counter0 Control register
    TCCR2 = (1<<CS22)|(1<<CS21)|(1<<CS20);  // clk_IO/1024 (From prescaler)
    TIMSK = (1<<TOIE2);                     // T/C0 Overflow interrupt Enable

    sei();                                  // Set I-bit Global interrupt
}

/************************************************************ Main Functions */
int main(void)
{        
    int i;

    sbi(DDRA,PA0);          // Set PA0 output
    cbi(PORTA,PA0);         // High PA0
        
    for (i=0;i<10;i++) {    // Toggle
        toggle(PORTA,PA0);
        delay_ms(500);
    }    

    Init_Timer2();          // Init Timer2 for Wake-up 
    
    while (1) {             // Loop forever

        toggle(PORTA,PA0);
        delay_ms(500);

        sleep_mode();       // Start Sleep Mode    
    }

	return 0;
}

/**************************************************** T/C2 Overflow Interrupt */
ISR (TIMER2_OVF_vect)
{  
    ;    
}
