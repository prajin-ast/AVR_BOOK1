/******************************************************************************
* Workfile    : EX0405.c
* Purpose     : PORTA0 Output & PORTA1 Input
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function


/************************************************************ Main Functions */
int main(void)
{  
	unsigned char i;

    DDRA = (0<<DDA1)|(1<<DDA0);    	// PORT PA0 Output & PA1 Input
	cbi(PORTA,0);              	    // Clear port
    
    while (1) {
//        if ((PINA&0x02)==0) {       // Check input PA1
        if ((PINA&(1<<PINA1))==0) { // Check input PA1
            sbi(PORTA,0);         	// Output high
        } else {                        
            cbi(PORTA,0);         	// Output low
        }   
    }

    return 0;
}
