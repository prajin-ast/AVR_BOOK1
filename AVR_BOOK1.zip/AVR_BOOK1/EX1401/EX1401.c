/******************************************************************************
* Workfile    : EX1401.c
* Purpose     : Analog to Digital Converter (ADC)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#include "lib_UART.c"  			// Use Module USART          

#define Vadc	1023			// 1023 (10-bit Resolution)

/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{       
	unsigned int adc;

    Init_Serial(96);				// Init Serial port  

	// AVCC with external capacitor at AREF pin
	ADMUX = (0<<REFS1)|(1<<REFS0);

	// ADC Enable & Auto Trigger Disable
	ADCSRA = (1<<ADEN)|(0<<ADATE);
	ADCSRA |= (0<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);	// XTAL/8
    
    while (1) {

        ADCSRA |= (1<<ADSC);			// ADC Start Conversion
        while (!(ADCSRA &(1<<ADIF)))    // Wait Coversion completes
            ;
		adc = ADCW;                     // Read ADC

		printf("\fAnalog to Digital Converter (ADC) \
				\nADC0: %d Voltage: %d.%d V", \ 
//				adc,(adc*5)/Vadc,(adc*5)%Vadc);	
				adc,(adc*5)/Vadc,(((adc*5)%Vadc)*10)/Vadc);	
        delay_ms(1000);                    // Delay 1s
    }

    return 0;
}
