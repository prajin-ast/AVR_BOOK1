/******************************************************************************
* Workfile    : Test_Board.c
* Purpose     : PORT All Output
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


/****************************************************************** delay_ms */
void delay_ms(unsigned int i)
{        
    for (; i>0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{      
    DDRA=0xFF;              // PORT A Output all
    DDRB=0xFF;              // PORT A Output all
    DDRC=0xFF;              // PORT A Output all
    DDRD=0xFF;              // PORT A Output all

    while (1) {
        PORTA = 0xFF;       // Output High
        PORTB = 0xFF;       // Output High
        PORTC = 0xFF;       // Output High
        PORTD = 0xFF;       // Output High
        delay_ms(1000);     // Delay 1s
        PORTA = 0x00;       // Output Low
        PORTB = 0x00;       // Output Low
        PORTC = 0x00;       // Output Low
        PORTD = 0x00;       // Output Low
        delay_ms(1000);
  }

  return 0;
}
