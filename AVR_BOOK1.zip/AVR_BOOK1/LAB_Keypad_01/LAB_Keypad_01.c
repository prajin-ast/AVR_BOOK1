/******************************************************************************
* Workfile    : LAB_Keypad_01.c
* Purpose     : Key switch Matrix (Keypad)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 
#include <stdio.h>          // Standard Input/Output

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "lib_UART.c"  		// Use Module USART          

/********************************************************************** Note */
// port P1 connect to key switch matrix pull-up
// Px.0 -> R1 , Px.1 -> R2
// Px.2 -> R3 , Px.3 -> R4
// Px.4 -> C1 , Px.5 -> C2
// Px.6 -> C3 , Px.7 not use

#define KEY_DATA_POUT		PORTA
#define KEY_DATA_PIN		PINA
#define KEY_DATA_DDR		DDRA
#define KEY_DATA_DDR_OUT 	((1<<DDA7)|(1<<DDA6)|(1<<DDA5)|(1<<DDA4))

/******************************************************************** Global */
const unsigned char kbd_pad[4][3] = {{'7','8','9'},
                                     {'4','5','6'},
                                     {'1','2','3'},
                                     {'*','0','#'}
                                     };

		
/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/******************************************************************* get_kbd */
// get key switch martix
unsigned char get_kbd()
{
    // x[110]1111, x[101]1111, x[011]1111
    unsigned char read_col[3] = { 0x6F, 0x5F, 0x3F }; 
    int col,row;   
    static char last_key;

    for (col=0;col<3;col++) {

        KEY_DATA_POUT = read_col[col];     	// read column 
        delay_ms(10);				 		// debounce

        row = KEY_DATA_PIN & 0x0F;        	// read row

        switch (row) {               
            case 0x0E: row = 3;
                break;
            case 0x0D: row = 2;
                break;
            case 0x0B: row = 1;
                break;
            case 0x07: row = 0;
                break;
            default:                    
                row = 4;
		}        

        if (row!=4) {
            if (kbd_pad[row][col] == last_key) return('\0');                   

            last_key = kbd_pad[row][col];
            return(kbd_pad[row][col]);
        }
    }

    last_key = '\0';
    return(last_key);
}

/************************************************************ Main Functions */
int main(void)
{        
   	char ch;

    Init_Serial(96);	// Init Serial port  

	KEY_DATA_DDR = KEY_DATA_DDR_OUT;    // Set Port Input/Output
 
    while (1) {        
        ch = get_kbd();
        if (ch !='\0')
            printf("KeyScan: %c\n\r",ch);       
    }

	return 0;
}
