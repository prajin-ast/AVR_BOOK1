/******************************************************************************
* Workfile    : AppLib03_PFCPWM.c
* Purpose     : Phase and Frequency Correct PWM Mode (Timer1)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files : Timer.c
* Ref         : Procyon AVRlib
******************************************************************************/

/*********************************************************** AVRlib Includes */
#include "C:\Book AVR\avrlib\timer.c"
#include "C:\Book AVR\avrlib\pulse.c"


/************************************************************ Main Functions */
int main(void)
{          	

	timerInit();        	// initialize the timer system
    timer1Init();           // initialize timer0
    timer1SetPrescaler(TIMER_CLK_DIV1024);  // Prescaler 1024

	sbi(DDRD, 5);           // Set PORTA0 for output

    timer1PWMInit(10);      // Bit period/resolution

    // set duty of timer1 Channel A (OC1A) PWM output 
    timer1PWMASet (2); // Set PWM Duty cycle
    timer1PWMAOn();


    while (1) {                 // Loop forever
        ;
    }

    return 0;
}
