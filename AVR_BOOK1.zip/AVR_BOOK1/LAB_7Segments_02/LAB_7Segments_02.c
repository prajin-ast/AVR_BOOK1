/******************************************************************************
* Workfile    : LAB_7Segments_02.c
* Purpose     : 7-Segments LED
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 
#include <stdio.h>          // Standard Input/Output

#define F_CPU 8000000UL         // 8 MHz
#include <util/delay.h>         // header file implement simple delay loops


/********************************************************************** Note */
// PORT Px connect to 7-Segments
// PORTA -> 7-Segments
// PORTB -> digit of 7-Segments (PB0-PB4)

#define DSP_DATA_POUT    	PORTA	    // DSPx enable (DIGIT PORT)
#define DSP_DATA_DDR		DDRA

#define LED_DATA_POUT		PORTB      	// LED Display (DATA_PORT)
#define LED_DATA_DDR		DDRB


/********************************************************** Global variables */
const unsigned char num_led[17] = {
					0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                    0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                    0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                    0x71, 0x80                     //F,.
                    };					

unsigned char num[4];		// buffer number led

		
/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/*************************************************************** display_led */
void display_led(unsigned int dly) 
{
    int i;

    for (i=0;i<dly;i++) {
        DSP_DATA_POUT = 0x07;           // 0b0111 (DSP1 enable active)
        LED_DATA_POUT = ~(num_led[num[0]]);			
        _delay_ms(2);

		DSP_DATA_POUT = 0x0B;           // 0b1011 (DSP2 enable active)
        LED_DATA_POUT = ~(num_led[num[1]]);
        _delay_ms(2);

		DSP_DATA_POUT = 0x0D;           // 0b1101 (DSP3 enable active)
        LED_DATA_POUT = ~(num_led[num[2]]);
        _delay_ms(2);

		DSP_DATA_POUT = 0x0E;           // 0b1110 (DSP4 enable active)
        LED_DATA_POUT = ~(num_led[num[3]]);
        _delay_ms(2);
    }
}

/************************************************************ Main Functions */
int main(void)
{        
	unsigned int count=0;

    LED_DATA_DDR = 0xFF;		// PORTB All output
    DSP_DATA_DDR = 0x0F;	    // PORT PA0-PA3 Output	

	num[3] = 0;
	num[2] = 0;
	num[1] = 0;
	num[0] = 0;

    while (1) {
                        		
		display_led(100);

        if (count++ >= 9999)
            count = 0;

	    num[3] = (count/1000);
	    num[2] = (count%1000)/100;
	    num[1] = ((count%1000)%100)/10;
        num[0] = ((count%1000)%100)%10;
    }

	return 0;
}
