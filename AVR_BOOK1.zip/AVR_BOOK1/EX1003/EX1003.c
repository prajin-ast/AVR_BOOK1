/******************************************************************************
* Workfile    : EX1003.c
* Purpose     : Interrupt UART Module
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         : "THE BEER-WARE LICENSE" (Revision 42)
******************************************************************************/

/****************************************************************** Includes */
#include <stdio.h>          // Standard Input/Output
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL     // CPU clock frequency (in Hertz)    
#include <util/delay.h>     // util_delay


/*********************************************************** Global variable */
unsigned int c;

/****************************************************************** delay ms */
void delay_ms(unsigned int i)
{
    for(;i>0;i--)
        _delay_ms(1);
}

/**************************************************************** put string */
void put_string(unsigned char *s)
{
    while (*s!=0) {
        loop_until_bit_is_set(UCSRA, UDRE);
        UDR = *s++;         // Transmit Data
    }
}

/*********************************************************** Initialize UART */
static void USART_Init(unsigned int baud)
{
	// Set baud rate
	UBRRH = (unsigned char) (baud>>8);
	UBRRL = (unsigned char) baud;
    
	// Enable receiver and tramsmitter
	UCSRB = (1<<RXEN)|(1<<TXEN);
    // Enable Interrupt
    UCSRB |= (1<<RXCIE)|(1<<TXCIE);
    // Set I-bit global interrupt enable
    sei();                  

	// Set frame format: 8data, NoneParity, 1stop bit
	UCSRC = (1<<URSEL)|(3<<UCSZ0);    
}

/************************************************************ Main Functions */
int main(void)
{        
    // PORT PA0,PA1,PA2 Output
    DDRA = (1<<DDA2)|(1<<DDA1)|(1<<DDA0);   

    // baudrate to 9,600 bps using a 8MHz crystal
    USART_Init(51);     

    put_string("\nUART Module : Serial port Input/Output\n\r");

    while(1) {              // Loop forever
        sbi(PORTA,2);       // Set bit
        delay_ms(500);      // Delay 0.5s
        cbi(PORTA,2);       // Clear bit
        delay_ms(500);
        cbi(PORTA,0);       // Clear bit
        cbi(PORTA,1);       // Clear bit
    }

    return 0;
}

/********************************************** USART, Rx Complete Interrupt */
ISR (USART_RXC_vect)
{  
    sbi(PORTA,0);           // Set bit

    c = UDR;                // Receive Data

    if (c == '\r') {
        UDR = '\n';         // New Line
        UDR = '\r';         // Return
        return;
    }
    
    loop_until_bit_is_set(UCSRA, UDRE);
    UDR = c;                // Transmit Data
            
    return;
}

/********************************************** USART, Tx Complete Interrupt */
ISR (USART_TXC_vect)
{  
    sbi(PORTA,1);           // Set bit 
    return;
}
