/******************************************************************************
* Workfile    : AppLib01_Timer.c
* Purpose     : Timer0
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files : Timer.c
* Ref         : Procyon AVRlib
******************************************************************************/

/*********************************************************** AVRlib Includes */
#include "C:\Book AVR\avrlib\timer.c"


/************************************************************ Main Functions */
int main(void)
{          
	timerInit();        	// initialize the timer system

    timer0Init();           // initialize timer0
    timer0SetPrescaler(TIMER_CLK_DIV1024);  // Prescaler 1024

	sbi(DDRA, 0);           // Set PORTA0 for output

    while (1) {             // Loop forever
        sbi(PORTA,0);       // PA0 High
        timerPause (1000);  // delay 1s
        cbi(PORTA,0);       // PA0 Low
        timerPause (1000);
    }

    return 0;
}
