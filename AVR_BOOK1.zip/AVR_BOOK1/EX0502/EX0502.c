/******************************************************************************
* Workfile    : EX0502.c
* Purpose     : External Interrupt (INT0/INT1)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

short int bit0=1;           // variable for toggle
short int bit1=1;


/****************************************************************** delay_ms */
void delay_ms(unsigned int i)
{        
    for (; i>0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{   
    MCUCR = (1<<ISC01)|(0<<ISC00);      // The falling edge of INT0
    MCUCR |= (1<<ISC11)|(0<<ISC10);     // The falling edge of INT1

    GICR  = (1<<INT1)|(1<<INT0);        // Enable INT0/INT1 interrupt
    sei();                              // Set I-bit Global interrupt

    DDRA  = (1<<DDA7)|(1<<DDA1)|(1<<DDA0);  // PORT A0,A1,A7 Output
    PORTA = (0<<PA7)|(0<<PA1)|(0<<PA0);     // Clear port

    while (1) {                     // Loop Forever
        sbi(PORTA,7);               // Set bit PA7
        delay_ms(500);              // Delay 0.5s
        cbi(PORTA,7);               // Clear bit PA7
        delay_ms(500);              // Delay 0.5s
    }

    return 0;
}

/*********************************************** External Interrupt Request 0 */
// Interrupt INT0 (PD2)
ISR (INT0_vect)
{  
    if (bit0) {
        sbi(PORTA,0);               // Set bit PA0
    } else {
        cbi(PORTA,0);               // Clear bit PA0
    }

    bit0 = !bit0;                   // Toggle bit
    delay_ms(200);                  // delay debound
}

/*********************************************** External Interrupt Request 1 */
// Interrupt INT1 (PD3)
ISR (INT1_vect)
{
    if (bit1) {
        sbi(PORTA,1);               // Set bit PA1
    } else {
        cbi(PORTA,1);               // Clear bit PA1
    }

    bit1 = !bit1;                   // Toggle bit
    delay_ms(200);                  // delay debound
}
