/******************************************************************************
* Workfile    : EX0604.c
* Purpose     : Timer0, External Event Counter
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>        // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function


/************************************************************ Main Functions */
int main(void)
{   
    // External clock source on T0 pin. 
    TCCR0 |= (1<<CS02)|(1<<CS01)|(1<<CS00); // Clock on rising edge.

    TIMSK = (1<<TOIE0);                     // T/C0 Overflow interrupt Enable

    SREG  = 0x80;                           // Set I-bit Global interrupt    
    
    DDRA  = (1<<DDA0);                      // PORT A0 Output
    PORTA = (0<<PA0);                       // Clear port
        
    while (1);                              // Loop nothing

    return 0;
}

/**************************************************** T/C0 Overflow Interrupt */
// Timer0 Counter Mode (PB0)
ISR (TIMER0_OVF_vect)
{  
    static char toggle=0;

    if (toggle) 
        sbi(PORTA,0);   // Set bit PA0
    else
        cbi(PORTA,0);   // Clear bit PA0        
    
    toggle = !toggle;   // Toggle
}
