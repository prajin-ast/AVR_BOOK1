/* 
Workfile : EX0201.c
Purpose  : PORTA Output
*/

#include <avr/io.h>         // AVR device-specific IO definitions


/* Main Functions */
int main(void)
{   
    DDRA = 0xFF;            // PORT A Output all
          
    while (1) {             // loop forever
    	PORTA = 0x00;       // Clear port
    	PORTA = 0xFF;       // Set port
    }

    return 0;
}
