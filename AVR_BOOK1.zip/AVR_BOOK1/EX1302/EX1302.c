/******************************************************************************
* Workfile    : EX1302.c
* Purpose     : Analog Comparator (Interrupt)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL     // CPU clock frequency (in Hertz)    
#include <util/delay.h>     // util_delay


/****************************************************************** delay_ms */
void delay_ms(unsigned int i)
{
    for(;i>0;i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{       
	// Set PA0 output port
	DDRA = (1<<DDA1)|(1<<DDA0);
	// Enable Interrupt, Output Toggle Interrupt Mode
	ACSR = (1<<ACIE)|(1<<ACIS1)|(1<<ACIS0);
	// Set I-bit global interrupt enable
    sei();                      

    while (1) {
		if (ACSR & (1<<ACO)) {
			sbi(PORTA,0);
		} else {
			cbi(PORTA,0);
		}
    }

    return 0;
}

/*********************************************** Analog Comparator Interrupt */
ISR (ANA_COMP_vect)
{  
    if (ACSR & (1<<ACO))
        sbi(PORTA,1);           // Set bit
    else
        cbi(PORTA,1);           // Clear bit

    delay_ms(10);
    return;
}
