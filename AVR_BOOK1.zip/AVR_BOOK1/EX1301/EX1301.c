/******************************************************************************
* Workfile    : EX1301.c
* Purpose     : Analog Comparator
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function


/************************************************************ Main Functions */
int main(void)
{       
	// Set PA0 output port
	DDRA = (1<<DDA0);
	// Analog Comparator Negative Input AIN1
	SFIOR = (0<<ACME);
  
    while (1) {
		// Check Analog Comparator Output (ACO)
		if ((ACSR & (1<<ACO))) {	
			// Voltage AIN0 > AIN1 (ACO is set)
			sbi(PORTA,0);			
		} else {
			// Voltage AIN0 < AIN1 (ACO is clear)
			cbi(PORTA,0);			
		}
    }

    return 0;
}
