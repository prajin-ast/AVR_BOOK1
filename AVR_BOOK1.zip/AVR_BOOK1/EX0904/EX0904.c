/******************************************************************************
* Workfile    : EX0904.c
* Purpose     : PWM, Phase and Frequency Corect (TOP = OCR1A)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

unsigned char toggleAM = 0;
unsigned char toggleBM = 0;
unsigned char toggleTOV = 0;


/************************************************************ Main Functions */
int main(void)
{       
    DDRA = (1<<DDA2)|(1<<DDA1)|(1<<DDA0);   // PORT PA0,PA1 PA2 Output    
    DDRD = (1<<DDD5)|(1<<DDD4);             // PORT PD5(OC1A),PD4(OC1B) Output PWM

    TCCR1A = (1<<COM1A1)|(0<<COM1A0);   // Clear up-counting Set downcounting
	TCCR1A |= (1<<COM1B1)|(0<<COM1B0);  // Clear up-counting Set downcounting

	// Mode 9: PWM,Phase and Frequency Corect (TOP = OCR1A)
    TCCR1B  = (1<<WGM13)|(0<<WGM12);    
    TCCR1A |= (0<<WGM11)|(1<<WGM10);      

    TCCR1B |= (1<<CS12)|(0<<CS11)|(0<<CS10); // clk_IO/256 (From prescaler)    

    OCR1A = 0x05FF;      // Output Compare Register 1 A
    OCR1B = 0x00FF;      // Output Compare Register 1 B

    TCNT1 = 0;          // Clear Timer
  
    TIMSK = (1<<OCIE1A);        // T/C1 Output Compare A Match interrupt Enable
    TIMSK |= (1<<OCIE1B);       // T/C1 Output Compare B Match interrupt Enable
    TIMSK |= (1<<TOIE1);        // T/C1 Overflow interrupt Enable
    sei();                      // Set I-bit global interrupt enable
    
    while (1) {                 // Loop nothing
        ;
    }

    return 0;
}

/********************************** Timer/Counter1 Compare Match A Interrupt */
ISR (TIMER1_COMPA_vect)
{  
    if (toggleAM) 
        sbi(PORTA,0);           // Set bit
    else
        cbi(PORTA,0);           // Clear bit

    toggleAM = !toggleAM;
        
    return;
}

/********************************** Timer/Counter1 Compare Match B Interrupt */
ISR (TIMER1_COMPB_vect)
{          
    if (toggleBM) 
        sbi(PORTA,1);           // Set bit 
    else
        cbi(PORTA,1);           // Clear bit

    toggleBM = !toggleBM;
        
    return;
}

/***************************************** Timer/Counter1 Overflow Interrupt */
ISR (TIMER1_OVF_vect)
{  
    if (toggleTOV) 
        sbi(PORTA,2);           // Set bit 
    else
        cbi(PORTA,2);           // Clear bit

    toggleTOV = !toggleTOV;

    return;
}
