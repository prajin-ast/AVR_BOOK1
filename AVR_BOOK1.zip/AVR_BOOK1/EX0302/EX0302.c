/******************************************************************************
* Workfile    : EX0302.c
* Purpose     : PORTA Output (PA0)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions


/************************************************************ Main Functions */
int main(void)
{   
    // Define directions for port pin output all
    DDRA = (1<<DDA7)|(1<<DDA6)|(1<<DDA5)|(1<<DDA4)|     
           (1<<DDA3)|(1<<DDA2)|(1<<DDA1)|(1<<DDA0);          
    // Clear port
	PORTA = (0<<PA7)|(0<<PA6)|(0<<PA5)|(0<<PA4)|        
            (0<<PA3)|(0<<PA2)|(0<<PA1)|(0<<PA0);          

	PORTA = (1<<PA0);   // PORT A0 output high
          
    while (1)           // loop forever
        ;

    return 0;
}
