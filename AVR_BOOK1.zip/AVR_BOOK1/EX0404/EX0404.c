/******************************************************************************
* Workfile    : EX0404.c
* Purpose     : Use Library PORT Output
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


/****************************************************************** delay_ms */
void delay_ms(unsigned int i)
{        
    for (; i>0; i--)
        _delay_ms(1);
}

/************************************************************ Main Functions */
int main(void)
{  
    outp(DDRA, 0xFF);           // PORTA Output
	outp(PORTA, 0x00);          // Clear port    
    
    while (1) {
        sbi(PORTA,0);           // Output High PA0
        sbi(PORTA,7);           // Output High PA7
        delay_ms(1000);         // Delay 1s
        sbi(PORTA,3);           // Output High PA3
        delay_ms(1000);         // Delay 1s

        cbi(PORTA,0);           // Output Low PA0
        cbi(PORTA,7);           // Output Low PA7        
        delay_ms(1000);         // Delay 1s
        cbi(PORTA,3);           // Output Low PA7        
        delay_ms(1000);         // Delay 1s
  }

  return 0;
}
