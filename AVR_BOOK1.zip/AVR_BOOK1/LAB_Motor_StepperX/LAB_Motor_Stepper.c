/******************************************************************************
* Workfile    : LAB_Motor_Stepper.c
* Purpose     : Stepper Motor Control (full step 1 phase)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define STEP_M_POUT		PORTA
#define STEP_M_DDR		DDRA
#define STEP_M_DDR_OUT 	((1<<DDA3)|(1<<DDA2)|(1<<DDA1)|(1<<DDA0))

		
/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************** Motor control */
/** Forward Stepper Motor */
void fw_step(uint8_t step, uint8_t dl)
{
    unsigned char n=0x01;

    while(step--) {
        STEP_M_POUT = n; 
        n = n<<1;           // shift left
        if (n == 0x10) 
            n = 0x01;
        delay_ms(dl);
    } 
}

/** Reward Stepper Motor */
void rw_step(uint8_t step, uint8_t dl)
{
    unsigned char n = 0x08;

    while(step--) {
        STEP_M_POUT = n; 
        n = n>>1;           // shift right
        if (n == 0x00) 
            n = 0x08;
        delay_ms(dl);
    } 
}

/************************************************************ Main Functions */
int main(void)
{        
	STEP_M_DDR = STEP_M_DDR_OUT;    // Set Port Input/Output
    
    while (1) {        
        fw_step(24,200);            // Forward step (CCW)
        delay_ms(1000);             // delay 1s
        rw_step(24,200);            // Reward step (CW)
        delay_ms(1000);             // delay 1s
    }

	return 0;
}
