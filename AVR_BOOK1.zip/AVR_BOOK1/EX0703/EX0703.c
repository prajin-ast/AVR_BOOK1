/******************************************************************************
* Workfile    : EX0703.c
* Purpose     : Compare  Output Mode (CTC Interrupt)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine


/************************************************************ Main Functions */
int main(void)
{       
    TCCR0 =  (1<<CS02)|(0<<CS01)|(1<<CS00);     // clk_IO/1024 (From prescaler)
    TCCR0 |= (1<<WGM01)|(0<<WGM00);             // Mode 2 CTC (T/C0 Mode of Operation)
    TCCR0 |= (1<<COM01)|(1<<COM00);             // Clear OC0 on compare match
    
    // T/C0 Output Compare Match interrupt Enable
    TIMSK = (1<<OCIE0);                             
    sei();                                  // Set I-bit global interrupt enable
    
    OCR0 = 0xFF;                            // Set OCR0 Compare Match        

    DDRB  = (1<<DDB3);                      // PORT PB3 Output
    PORTD = (1<<PD3);                       // Set port

    DDRA  = (1<<DDA0);                      // PORT PA0 Output
    PORTA = (0<<PA0);                       // Clear port
    
    while (1);                              // Loop nothing

    return 0;
}

/********************************************** T/C0 Compare Match Interrupt */
ISR (TIMER0_COMP_vect)
{  
    PORTA = !(PORTA);                       // Toggle PA0
    return;
}
