/******************************************************************************
* Workfile    : EX1502.c
* Purpose     : EEPROM Memory
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <stdio.h>          // Standard Input/Output
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/eeprom.h>     // EEPROM Library

#include "lib_UART.c"		// Use UART Library


/************************************************************ Main Functions */
int main(void)
{
    unsigned char ucData;
	unsigned int iAddr;

   	Init_Serial(96);
    printf("\nEEPROM Example\n");

	// Write a byte to EEPROM
	for (iAddr=0x0000; iAddr<=0x000F; iAddr++)
    	eeprom_write_byte(iAddr,0xAB);			

	// Read a byte from EEPROM
	for (iAddr=0x0000; iAddr<=0x000F; iAddr++) {
    	ucData = eeprom_read_byte(iAddr);			
    	printf("EEPROM value @ 0x%04X is 0x%02X\n",iAddr, ucData);
	}
    
    while (1);              // Loop nothing
	
	return 0;
}
