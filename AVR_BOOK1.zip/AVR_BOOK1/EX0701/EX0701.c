/******************************************************************************
* Workfile    : EX0701.c
* Purpose     : Compare  Output Mode (CTC)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions


/************************************************************ Main Functions */
int main(void)
{       
    TCCR0 =  (1<<CS02)|(0<<CS01)|(1<<CS00);     // clk_IO/1024 (From prescaler)
    TCCR0 |= (1<<WGM01)|(0<<WGM00);             // Mode 2 CTC (T/C0 Mode of Operation)
    TCCR0 |= (0<<COM01)|(1<<COM00);             // Toggle OC0 on compare match

    OCR0 = 0xFF;                                // Set OCR0 Compare Match
        
    DDRB  = (1<<DDB3);                          // PORT PB3 Output

    while (1);                                  // Loop nothing

    return 0;
}
