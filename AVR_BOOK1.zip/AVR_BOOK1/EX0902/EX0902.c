/******************************************************************************
* Workfile    : EX0902.c
* Purpose     : Calculate frequency
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine

#include "lib_UART.c"           // Use UART Library


unsigned int pulse_count=0;     // Set Pulse Count
unsigned int wait_1sec=0;       // wait time for pulse count    

/************************************************************ Main Functions */
int main(void)
{       
    TCCR1B  = (0<<CS12)|(1<<CS11)|(0<<CS10); // clk_IO/8 (From prescaler)

    // Activates Noise Canceler and Input Capture falling edgs
    TCCR1B |= (1<<ICNC1)|(1<<ICES1);         
    
    TCNT1 = 15536;              // Start counter

    TIMSK = (1<<TICIE1);        // Input Capture interrupt Enable
    TIMSK |= (1<<TOIE1);        // T/C1 Overflow interrupt Enable
    sei();                      // Set I-bit global interrupt enable
    
    
    DDRD  = (0<<DDB6);          // PORT PD6(ICP1) Input 

    Init_Serial(96);            // baudrate to 9,600 bps using a 8MHz crystal   
    
    fprintf(&uart_str,"\fWait..! frequency count");
    
    while (1);                  // Loop nothing

    return 0;
}

/****************************************** Timer/Counter1 Capture Interrupt */
ISR (TIMER1_CAPT_vect)
{  
    pulse_count++;
}

/***************************************** Timer/Counter1 Overflow Interrupt */
ISR (TIMER1_OVF_vect)
{  
    // T = 1/f = 1/(8M/prescaler8)
    //   = 1/(8M/8) = 1 us
    // Overflow 50000 x 1us = 0.05s (Start count at 15536)
    // 
    // 0.05 s   =   1 OV
    // 1s       = 1/0.05
    //          = 20 Overflow 
    //        
    if (wait_1sec++>19) {
        fprintf(&uart_str,"\fFrequency count: %d",pulse_count);
        pulse_count = 0;    // Clear pulse count
        wait_1sec = 0;      // Clear wait 1s
    }
    TCNT1 = 15536;  // Start counter
    return;
}
