/******************************************************************************
* Workfile    : EX1001.c
* Purpose     : UART Module
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         : "THE BEER-WARE LICENSE" (Revision 42)
******************************************************************************/

/****************************************************************** Includes */
#include <stdio.h>          // Standard Input/Output
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine

#define F_CPU 8000000UL     // CPU clock frequency (in Hertz)    
#include <util/delay.h>     // util_delay


/******************************************************* Prototype functions */
static int uart_putchar(char c, FILE *stream);
static FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, NULL,_FDEV_SETUP_WRITE);
static void delay_1s(void);


/****************************************************************** delay_1s */
static void delay_1s(void)
{
    uint8_t i;

    for (i = 0; i < 100; i++)
        _delay_ms(10);
}

/************************************************************* USART putchar */
static int uart_putchar(char c, FILE *stream)
{
    if (c == '\a') {
        fputs("*ring*\n", stderr);
        return 0;
    }

    if (c == '\n')
        uart_putchar('\r', stream);
    
    loop_until_bit_is_set(UCSRA, UDRE);
    UDR = c;

    return 0;
}

/*********************************************************** Initialize UART */
static void USART_Init(unsigned int baud)
{
	  // Set baud rate
	  UBRRH = (unsigned char) (baud>>8);
	  UBRRL = (unsigned char) baud;
    
	  // Enable receiver and tramsmitter
	  UCSRB = (1<<RXEN) | (1<<TXEN);

	  // Set frame format: 8data, NoneParity, 1stop bit
	  UCSRC = (1<<URSEL)|(3<<UCSZ0);

    // Set address uart_str to stdout
    stdout = &uart_str;     
}

/************************************************************ Main Functions */
int main(void)
{        
    int i=99;

    USART_Init(51);     // baudrate to 9,600 bps using a 8MHz crystal

    fprintf(&uart_str,"\nUART Module : Serial communication device");
    fprintf(&uart_str,"\nCountdown....");

    while(1) {          // Loop forever                  

        fprintf(&uart_str,"\nNumber %d",i);
        if (i-- <= 0) break;
        delay_1s();     // Delay 1 sec
    }

    return 0;
}
