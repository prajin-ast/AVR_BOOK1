/******************************************************************************
* Workfile    : EX0301.c
* Purpose     : PORTA Output (PA0)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions


/************************************************************ Main Functions */
int main(void)
{  
    DDRA=0xFF;          // PORT A Output all
	PORTA=0x00;         // Clear port

    PORTA = 0x01;       // output high PA0

    while (1)           // loop nothing
        ;

    return 0;
}
