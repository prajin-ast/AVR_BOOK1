//***********************************************************
// ICCV7 AVR (demo ver.) application builder setup for
// controlling hobby servos at 50Hz.
// Using ATMEGA32 at 8MHz.
// Timer1 is the 16bit timer used to controll 2 servos
// on pins OC1A and OC1B.
//***********************************************************
// ICCV7 AVR APPLICATION BUILDER SETUP
//***********************************************************
//
// CPU tab:    Target CPU        = M32
//             Xtal speed (MHz)  = 8.0000
//
// Timer1 tab: Use Timer1        = check
//             Desired value     = 50
//             Units             = Hz
//             Prescale          = 8
//             OC1A output mode  = Cleared
//             OC1B output mode  = Cleared
//             Waveform mode     = 14
//
// Ports tab:  Set port D as output.
//***********************************************************

//********************************************
// Target CPU        = M32
// Xtal speed (MHz)  = 8.0000
// Controls two servos at 50Hz pulse.
//********************************************
//********************************************
void init_servo_driver(void);   //prototype
//********************************************
int main(void)
{
    unsigned int servo_a;
    unsigned int servo_b;

    init_servo_driver();

//    servo_a = 1500;
//    servo_b = 1500;

    servo_a = 20000;
    servo_b = 1500;

    while(1)
    {
         OCR1A = servo_a;
         OCR1B = servo_b;
    } 
    return 0;
}
//********************************************
void init_servo_driver(void)
{
    TCCR1B = 0x00;  //stop timer
    DDRD   = 0xFF;  //set pins for output
    TCNT1H = 0xB1;  //setup
    TCNT1L = 0xE1;
    ICR1   = 20000; // used for TOP, makes for 50 hz
//    OCR1A  = 1500;  // servo at center (1.5ms pulse)
//    OCR1B  = 1500;  // servo at center (1.5ms pulse)
    OCR1A  = 20000;  // servo at center (1.5ms pulse)
    OCR1B  = 1500;  // servo at center (1.5ms pulse)
    TCCR1A = 0xA2;
    TCCR1B = 0x1A;  //start timer
}
//********************************************
