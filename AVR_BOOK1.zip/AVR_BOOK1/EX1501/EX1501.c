/******************************************************************************
* Workfile    : EX1501.c
* Purpose     : EEPROM Memory
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <stdio.h>          // Standard Input/Output
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine

#include "lib_UART.c"		// Use UART Library


/*********************************************************** EEPROM_ReadByte */
unsigned char EEPROM_ReadByte(unsigned int uiAddress)
{    
	// Wait for completion of previous write
    while (EECR&(1<<EEWE))			
        ;
    
	// Set up address and data register
	EEAR = uiAddress;				    
    // Start eeprom read by writing EERE
    EECR |= (1<<EERE);
    
	// Return data from data  register
    return EEDR;
}

/********************************************************** EEPROM_WriteByte */
void EEPROM_WriteByte(unsigned int uiAddress, unsigned char ucData)
{
	// Wait for completion of previous write
    while (EECR&(1<<EEWE))			
        ;
    
	// Set up address and data register
	EEAR = uiAddress;				    
    EEDR = ucData;
    
	// Write logical one to EEMWE
    EECR |= (1<<EEMWE);
	// Start eeprom write by setting EEWE
    EECR |= (1<<EEWE);    
}

/************************************************************ Main Functions */
int main(void)
{
    unsigned char ucData;
	unsigned int iAddr;

   	Init_Serial(96);
    printf("\nEEPROM Example\n");

	// Write a byte to EEPROM
	for (iAddr=0x0000; iAddr<=0x000F; iAddr++)
    	EEPROM_WriteByte(iAddr,0xAB);			

	// Read a byte from EEPROM
	for (iAddr=0x0000; iAddr<=0x000F; iAddr++) {
    	ucData = EEPROM_ReadByte(iAddr);			
    	printf("EEPROM value @ 0x%04X is 0x%02X\n",iAddr, ucData);
	}
    
    while (1);              // Loop nothing
	
	return 0;
}
