/******************************************************************************
* Workfile    : EX0603.c
* Purpose     : Timer0 Clock
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <stdio.h>          // Standard Input/Output

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine


unsigned int count=0;		// Variable for count in interrupt function
unsigned int sec,min,hr;    // second, minute, hour
unsigned int hk=0;

static int uart_putchar(char c, FILE *stream);
static FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, 
                                         NULL,_FDEV_SETUP_WRITE);


/*********************************************************** Initialize UART */
void USART_Init(unsigned int baud)
{
	// Set baud rate
	UBRRH = (unsigned char) (baud>>8);
	UBRRL = (unsigned char) baud;
    
	// Enable receiver and tramsmitter
	UCSRB = (1<<RXEN) | (1<<TXEN);

	// Set frame format: 8data, NoneParity, 1stop bit
	UCSRC = (1<<URSEL)|(3<<UCSZ0);
}

/************************************************************* USART putchar */
int uart_putchar(char c, FILE *stream)
{
    if (c == '\a') {
        fputs("*ring*\n", stderr);
        return 0;
    }

    if (c == '\n')
        uart_putchar('\r', stream);
    
    loop_until_bit_is_set(UCSRA, UDRE);
    UDR = c;

    return 0;
}

/************************************************************ Main Functions */
int main(void)
{   
    // Set Timer/Counter0 Control register
    TCCR0 = (1<<CS02)|(0<<CS01)|(1<<CS00);  // clk_IO/1024 (From prescaler)
    TIMSK = (1<<TOIE0);                     // T/C0 Overflow interrupt Enable

    SREG  = 0x80;                           // Set I-bit Global interrupt    

    DDRA  = (1<<DDA0);                      // PORT A0 Output
    PORTA = (0<<PA0);                       // Clear port

    sec = 0;                                // Set sec
    min = 10;                               // Set min
    hr  = 10;                               // Set hr            
    stdout = &uart_str;                     // Set address uart_str to stdout

    // Set the baudrate to 9,600 bps using a 8MHz crystal
    USART_Init( 51 );  

    while (1) {             // Loop forever
        if (hk) {
            fprintf(&uart_str,"\f\nTime %d:%d:%d\n",hr,min,sec);
            hk = 0;         // Clear for wait 
        }
    }
    return 0;
}

/**************************************************** T/C0 Overflow Interrupt */
ISR (TIMER0_OVF_vect)
{  
    if (count++ > 29) {                
        count = 0;                          // Clear counter  
        if (sec++>59) {        
            sec = 0;                        // Clear SEC
            if (min++ > 59) {                
                min =0;                     // Clear MIN
                if (hr++ > 24) 
                    hr = 0;                 // Clear Hr
            }            
        }
        hk = 1;                             // For display in main loop
        PORTA = !(PORTA);                   // Output high PA0        
    }
}
