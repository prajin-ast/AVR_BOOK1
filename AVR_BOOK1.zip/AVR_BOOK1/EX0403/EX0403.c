/******************************************************************************
* Workfile    : EX0403.c
* Purpose     : PORTA0&1 Output
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


/****************************************************************** delay_ms */
void delay_ms(unsigned int i)
{        
    for (; i>0; i--)
        _delay_ms(10);
}

/************************************************************ Main Functions */
int main(void)
{  
    DDRA= (1<<DDA0)|(1<<DDA1);       // PORT A0 & A1 Output
	PORTA=(0<<PA0)|(0<<PA1);         // Clear port
    
    while (1) {
        PORTA = (1<<PA0)|(1<<PA1);   // Output High
        delay_ms(1000);              // Delay 1s
        PORTA = (0<<PA0)|(0<<PA1);   // Output Low
        delay_ms(1000);
  }

  return 0;
}
