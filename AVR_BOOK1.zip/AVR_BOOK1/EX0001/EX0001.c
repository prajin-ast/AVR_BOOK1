/* 
Workfile : EX0001.c
Purpose  : PORTA Input/Output
*/

#include <avr/io.h>         // AVR device-specific IO definitions


/* Main Functions */
int main(void)
{   
    DDRA = 0xF0;            // PORTA, PA7-PA4 Output, PA3-PA0 Input
	PORTA = 0x00;          	// Clear All Port

    while (1) {             // Loop Forever
                
        if((~PINA&0x01)==0x01)	// Check PA0
            PORTA = 0x10;       // Set PA4

        if((~PINA&0x02)==0x02)	// Check PA1
            PORTA = 0x20;       // Set PA5

        if((~PINA&0x04)==0x04)	// Check PA2
            PORTA = 0x40;       // Set PA6

        if((~PINA&0x08)==0x08)	// Check PA3
            PORTA = 0x80;       // Set PA7
      
		PORTA = 0x00;			// Clear All Port
    }

    return 0;
}
