/******************************************************************************
* Workfile    : LAB_Motor_Stepper.c
* Purpose     : Stepper Motor Control (full step 1 phase)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Deprecated items 

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define STEP_M_POUT		PORTA
#define STEP_M_DDR		DDRA
#define STEP_M_DDR_OUT 	((1<<DDA3)|(1<<DDA2)|(1<<DDA1)|(1<<DDA0))

uint8_t fs1p[4] = { 0x01,0x02,0x04,0x08 };  //data full step 1 phase

		
/***************************************************************** delay_ms */
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/************************************************************** Motor control */
/** Forward Stepper Motor */
void fw_step(uint8_t step, uint8_t dl)
{
    unsigned char n = 0;

    while(step--) {
        STEP_M_POUT = fs1p[n];
        if (n++ == 3) 
            n = 0;
        delay_ms(dl);
    } 
}

/** Reward Stepper Motor */
void rw_step(uint8_t step, uint8_t dl)
{
    unsigned char n = 3;

    while(step--) {
        STEP_M_POUT = fs1p[n]; 
        if (n-- == 0) 
            n = 3;
        delay_ms(dl);
    } 
}

/************************************************************ Main Functions */
int main(void)
{        
	STEP_M_DDR = STEP_M_DDR_OUT;    // Set Port Input/Output
    
    while (1) {        
        fw_step(24,200);            // Forward step (CCW)
        delay_ms(1000);             // delay 1s
        rw_step(24,200);            // Reward step (CW)
        delay_ms(1000);             // delay 1s
    }

	return 0;
}
