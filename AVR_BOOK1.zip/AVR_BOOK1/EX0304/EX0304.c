/******************************************************************************
* Workfile    : EX0304.c
* Purpose     : IF/For/While Control 
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions


/**************************************************************** loop_delay */
void loop_delay(unsigned long count1)
{
    long i;
    while (count1-- > 0) {  // Decrease Counter
		for(i=0;i<5000;i++)
		;
    }
}

/************************************************************ Main Functions */
int main(void)
{   
    int i,j;

    DDRA= 0xFF;                     // PORT A Output all
	PORTA=0x00;                     // Clear port

    for (i=0;i<10;i++) {            // loop if i<10            
        for (j=0;j<50;j++) {        // loop if j <50
            if (j<25) {          
                PORTA=(1<<PA0);     // do if j < 25
                loop_delay(5000);
                PORTA=(0<<PA0); 
                loop_delay(5000);
            } 
            if (j>=25) {
                PORTA=(1<<PA7);     // do if j >= 25
                loop_delay(5000);
                PORTA=(0<<PA7); 
                loop_delay(5000);
            }
        }
    }

    while (1)           // loop nothing
        ;

    return 0;
}
