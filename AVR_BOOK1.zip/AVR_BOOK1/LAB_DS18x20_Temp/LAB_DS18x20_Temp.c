/******************************************************************************
* Workfile    : LAB_DS18x20_Temp.c
* Purpose     : DS18B20 1-Wire Digital Thermometer
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <string.h>         // String Library

#define F_CPU 8000000UL     // 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "lib_1wire.c"      // Dallas 1-Wire Library
#include "lib_UART.c"       // UART Library 
#include "lcd.c"		    // LCD function Library

// for test program output to computer with serial port
//#define TEST_SERIAL	

/********************************************************** Global variables */
char buf_Tempc[15];


/************************************************************ LCD Put String */
void lcdPutString(char *text)
{
	while ( *text ) {			// while not end of text
  	
  		lcdDataWrite(*text++); 	// Write character and increment position
  	} 

	return;
}

/********************************************************** ReadTemp_DS18B20 */
// Read Temperature DS18B20
void ReadTemp_DS18B20(void)
{
    char get[10], k, res[5]={"0"};
    int temp, temp_lsb, temp_msb;

	ow_reset();
	WriteByte(0xCC); // Skip ROM
	WriteByte(0x44); // Start Conversion
	
	delay_us(120);
	ow_reset();
	WriteByte(0xCC); // Skip ROM
	WriteByte(0xBE); // Read Scratch Pad
	
	for(k=0; k<9; k++)
		get[k] = ReadByte(); 

	temp_msb = get[1];	
	temp_lsb = get[0];

    temp = ((temp_msb&0x0F)<<4);    // Temperature
    temp|= ((temp_lsb&0xF0)>>4);

    if((temp_msb&0xF0)==0xF0) temp = (-1)*temp; // Sign bit
    // resolution of the temperature  
    if ((temp_lsb&0x0F)==0x08)  strcpy(res,"5");         
    if ((temp_lsb&0x0F)==0x02)  strcpy(res,"125");
    if ((temp_lsb&0x0F)==0x01)  strcpy(res,"0625");
		
	#ifdef TEST_SERIAL
		printf("\nTempC = %d.%s C",(int)temp,res);
	#else
        sprintf(buf_Tempc, "Temp: %d.%s%cC", (int)temp,res,0xDF);
	#endif
}


/************************************************************ Main Functions */
int main(void) {
    
#ifdef TEST_SERIAL

    // initializing for stream I/O
    Init_Serial(96);

	while (1) {
        printf("\fDS18B20(1-Wire Temperature)");
		ReadTemp_DS18B20();
        delay_1s();
    }

#endif

	lcdInit();          // LCD Initialize

	lcdGotoXY(1,0); 
	lcdPutString("DS18B20 1-Wire");

	while (1) {
		ReadTemp_DS18B20();
    	lcdGotoXY(1,1);
	    lcdPutString("Temp:           ");
    	lcdGotoXY(1,1); 
	    lcdPutString(buf_Tempc);	        
        delay_1s();
	}

    return 0;
}
