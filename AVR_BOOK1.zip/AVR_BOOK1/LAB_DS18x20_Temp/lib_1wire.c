/******************************************************************************
* Workfile    : lib_1wire.c
* Purpose     : DS18B20 1-Wire Digital Thermometer (Temperature Sensor)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/***************************************************************** Constants */
#define BIT_DQ  0		    // 1-Wire Interface (DS18B20 Temp. Sensor)

#define SET_IN_DQ       cbi(DDRA,BIT_DQ)
#define SET_OUT_DQ      sbi(DDRA,BIT_DQ)
#define OUT_HIGH_DQ     sbi(PORTA,BIT_DQ)
#define OUT_LOW_DQ      cbi(PORTA,BIT_DQ)
#define IN_DQ           (PINA&(1<<BIT_DQ))

#define delay   delay_us

/***************************************************************** Data Type */
typedef unsigned char byte;
typedef unsigned int  word;


/******************************************************** Function prototypes */
void delay_us(word time_us);
byte ow_reset(void);
byte read_bit(void);
void wirte_bit(char bitval);
byte ReadByte(void);
void WriteByte(char val);


/**************************************************** 1-Wire Library Function */
// 1-Wire Delay
void delay_us(word time_us) 
{
	for ( ;time_us>0; time_us--)
		_delay_us(1);			
}

// 1-Wire Reset
byte ow_reset(void)
{
	byte presence;

    SET_OUT_DQ;         // Set output port

	OUT_LOW_DQ;	        // pull DQ line low
	delay_us(480);      // leave it low for 480us
	OUT_HIGH_DQ;	    // allow line to return high
	delay_us(50);       // delay 15us-60us wait for presence

    SET_IN_DQ;          // Set input port
    
	presence = IN_DQ;   // get presence signal
	delay_us(220);      // delay 60-240us wait for end of timeslot

	return(presence); 	// presence signal returned	
                        // 0=presence, 1 = no part
}  			

// 1-Wire Write Bit
void wirte_bit(char bitval)
{
    SET_OUT_DQ;         // Set output port

	OUT_LOW_DQ;		    // pull DQ low to start timeslot	
	if(bitval == 1)     // return DQ high if wirte "1"
        OUT_HIGH_DQ;	

    // hold value for remainder of timeslot (60us-120us) 
	delay_us(100);
	OUT_HIGH_DQ;        		
}

// 1-Wire Read Bit
byte read_bit(void)
{
    SET_OUT_DQ;         // Set output port

	OUT_LOW_DQ;         // pull DQ low to start timeslot
    OUT_HIGH_DQ;		// then return high
    delay_us(10);       // delay 15us from start of timeslot

    SET_IN_DQ;          // Set input port
	return(IN_DQ);      // Return value of DQ line
}


// 1-Wire Read Byte
byte ReadByte(void)
{
	byte i;
	byte value = 0;

	for(i=0; i<8; i++) {
		if(read_bit()) 			// reads byte in,one byte at a time 
 			value|=0x01<<i;		// and then shifts it left
	    delay_us(150);			// wait for	rest for timeslot
	}
	return(value);
}

// 1-Wire Write Byte
void WriteByte(char val)
{
	byte i;
	byte temp;

	for(i=0; i<8; i++) {	// writes byte, one bit at a time
	  	temp = val>>i;		// shifts val right 'i' spaces	
		temp &= 0x01;		// copy that bit to temp
		wirte_bit(temp);	// write bit in temp into
	}
	delay_us(100);
}

