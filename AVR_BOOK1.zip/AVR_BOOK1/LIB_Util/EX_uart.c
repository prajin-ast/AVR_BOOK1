/******************************************************************************
* Workfile    : EX_UART.c
* Purpose     : Using the AVR UART in C (polled USART)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega16
* Other Files :
* Ref         :
******************************************************************************/

/****************************************************************** Includes */
#include <avr/io.h>         // AVR device-specific IO definitions
#include <stdio.h>


/*********************************************************** Initialize UART */
void USART_Init(unsigned int baud)
{
	// Set baud rate
	UBRRH = (unsigned char) (baud>>8);
	UBRRL = (unsigned char) baud;
    
	// Enable receiver and tramsmitter
	UCSRB = (1<<RXEN) | (1<<TXEN);

	// Set frame format: 8data, NoneParity, 1stop bit
	UCSRC = (1<<URSEL)|(3<<UCSZ0);
}

/************************************************** Read and write functions */
unsigned char USART_Receive( void )
{
	// Wait for incomming data
	while ( !(UCSRA & (1<<RXC)) ) 	
		;			                
	// Return the data
	return UDR;
}

void USART_Transmit( unsigned char data )
{
	// Wait for empty transmit buffer
	while ( !(UCSRA & (1<<UDRE)) )
		; 			                
	// Start transmittion
	UDR = data; 			        
}

/************************************************************ Main Functions */
int main( void )
{
	USART_Init( 51 );  // Set the baudrate to 9,600 bps using a 8MHz crystal

	for(;;) {	        // Forever	
		USART_Transmit( USART_Receive() ); // Echo the received character
    }

    return 0;
}
